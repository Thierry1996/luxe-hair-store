# Luxe Hair Store

React + Node project for premium hair ecommerce.